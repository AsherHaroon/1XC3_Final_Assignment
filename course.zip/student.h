/**
 * @file student.h
 * @author Asher Haroon (harooa5@mcmaster.ca)
 * @brief A student type struct definition which stores a students first name, last name, ID, their grades, and the total number of grades
 * @version 0.1
 * @date 2022-04-10
 * 
 * @copyright Copyright (c) 2022
 * 
 */

typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

/** @brief Method definitions for obtaining or setting student information */
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
