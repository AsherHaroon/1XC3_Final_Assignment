/**
 * @file course.h
 * @author Asher Haroon (harooa5@mcmaster.ca)
 * @brief Header containing Course type definiton and Course function declarations which are implemented by course.c
 * @version 0.1
 * @date 2022-04-10
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief A type struct containing information about a course storing:
 *  Course Name
 *  Course Code
 *  List of Students Enrolled in the Course
 *  Total Number of Students Enrolled in the Course
 */

typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

/**
 * @brief This function enrolls students into a course
 * 
 * @param course The course the student is enrolling into
 * @param student The student that is being enrolled
 */

void enroll_student(Course *course, Student *student);

/**
 * @brief This function prints out course information
 * 
 * @param course The course to print the information for
 */

void print_course(Course *course);

/**
 * @brief This function finds the student with the highest average in a given coures
 * 
 * @param course The course of which the function is finding the top student of
 * @return Top performing student (Student*)
 */

Student *top_student(Course* course);

/**
 * @brief This function is used to return students that are passing the course
 * 
 * @param course The course that is being observed
 * @param total_passing A pointer to store the total students are passing
 * @return A list of students that are passing (Student*)
 */

Student *passing(Course* course, int *total_passing);


