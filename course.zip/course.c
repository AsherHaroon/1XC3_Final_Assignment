/**
 * @file course.c
 * @author Asher Haroon (harooa5@mcmaster.ca)
 * @brief File containing functions to enroll students into courses, print course information, finding top students, and finding passing students
 * 
 * @version 0.1
 * @date 2022-04-10
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief This function enrolls students into a course
 * 
 * @param course The course the student is enrolling into
 * @param student The student that is being enrolled
 */

void enroll_student(Course *course, Student *student)
{
  course->total_students++; // Increments total number of students for that course
  /* If this is the first student that is being enrolled into this course,
  then allocate the array of students for one student, otherwise,
  reallocate the array to store the total number of students.
  */
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  // Sets the last element of the array of students to the current student
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief This function prints out course information
 * 
 * @param course The course to print the information for
 */

void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // Loop that prints out all the students currently enrolled in that course
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief This function finds the student with the highest average in a given coures
 * 
 * @param course The course of which the function is finding the top student of
 * @return Top performing student (Student*)
 */

Student* top_student(Course* course)
{
  // In the case the course has no students, no average is returned
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  // Sets max average and student to the first to the first student in the list
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];

  /* Loops through each student in the course,
  if the student's average is higher than the max average,
  then the student is set to the new top student */

  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief This function is used to return students that are passing the course
 * 
 * @param course The course that is being observed
 * @param total_passing A pointer to store the total students are passing
 * @return A list of students that are passing (Student*)
 */

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  /* Loops through students and finds the number of students in the course with
  an average higher than 50 */
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  // Creates an array with size of the number of students passing
  passing = calloc(count, sizeof(Student));

  int j = 0;
  // Loops through students and adds students that are passing to the array of passing students
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  // Updates the pointer to store the number of students passing
  *total_passing = count;

  // Returns the array of students that passed
  return passing;
}