/**
 * @file student.c
 * @author Asher Haroon (harooa5@mcmaster.ca)
 * @brief File containing functions to add new grades to students, calculate average grades for students, print student information, and generate random students
 * @version 0.1
 * @date 2022-04-10
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Function that adds a new grade to the student's list of grades
 * 
 * @param student The student that the new grade is being added to
 * @param grade The new grade to be added
 */

void add_grade(Student* student, double grade)
{
  student->num_grades++; // Increments the total number of grades this student has by 1
  /* If only one grade exists then only the size of one double is allocated to the list of grades,
  otherwise, the list of grades is reallocated memory to have size that stores an additoinal grade
  */
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  // Adds grade to the end of the list of grades
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief This function calculates the average grade of a student
 * 
 * @param student Student to find average of
 * @return double Student's average grade
 */

double average(Student* student)
{
  // If the student does not have any grades, function returns 0
  if (student->num_grades == 0) return 0;

  double total = 0;
  // Adds up all the student's grades
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  // Returns the average grade by dividing the sum of the grades by the number of grades
  return total / ((double) student->num_grades);
}

/**
 * @brief This function prints out the student's information
 * 
 * @param student Student to print out information of
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  // Loops through student's grades to print each grade
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief This function generates a random student with a certain number of grades
 * 
 * @param grades The number of grades the student being generated should have
 * @return Returns the random student (Student*)
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};

  // Allocates memory with size of a student type to the newly generated student
  Student *new_student = calloc(1, sizeof(Student));

  // Randomly generates first and last name from the arrays above
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // Fill student's list of grades with random numbers
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  // Returns the newly generated student
  return new_student;
}